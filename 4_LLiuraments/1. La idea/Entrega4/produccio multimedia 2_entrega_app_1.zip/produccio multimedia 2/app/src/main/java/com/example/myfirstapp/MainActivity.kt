package com.example.myfirstapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);
        var n = 0;
        var t  = 1;
        button.setOnClickListener {
            val tv: TextView = findViewById(R.id.textView)

            if(n ==  1) {
                tv.text = "Hello world!"
                n = 0;
                t = 0;
            }
            if(n ==  0) {
                if(t ==  1) {
                    tv.text = " "
                    n = 1;
                }}
            t = 1
        }




}}